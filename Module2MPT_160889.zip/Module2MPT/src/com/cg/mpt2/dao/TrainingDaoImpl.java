package com.cg.mpt2.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.mpt2.dto.Training;


@Repository("trainingdao")
 public class TrainingDaoImpl implements TrainingDao{
    @PersistenceContext
    EntityManager em;
    
    /******************************************************************************************************
          - Function Name	    :   viewTaineeData
          - Creation Date	    :	01/11/2018
          - Description		    :	ViewTrainingdetails
      
     *******************************************************************************************************/
    
	@Override
	public List<Training> showDetails() 
	  {
		
		Query query = em.createQuery("FROM Training");
		@SuppressWarnings("unchecked")
		List<Training> list = query.getResultList();
		return list;
		
	  }

}
