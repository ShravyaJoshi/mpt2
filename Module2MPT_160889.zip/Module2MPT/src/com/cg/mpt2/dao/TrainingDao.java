package com.cg.mpt2.dao;

import java.util.List;

import com.cg.mpt2.dto.Training;



  public interface TrainingDao 
    {
	/***********************************************************
	          To Show Details Of the Trainee
	 
	 ***********************************************************/
	  public List<Training> showDetails();
	  
   }
