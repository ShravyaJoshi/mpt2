package com.cg.mpt2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mpt2.dto.Training;
import com.cg.mpt2.service.TrainingService;


//Spring Controller 
@Controller
    public class TrainingController
  {
	// Auto wiring used for wiring from one layer to another layer
   @Autowired
         TrainingService trainingservice;

   /*******************************************************************************************************
          - Function Name	    :   viewTaineeData
          - Creation Date	    :	01/11/2018
          - Description		    :	ViewTrainingdetails
    ********************************************************************************************************/

   @RequestMapping(value="showall",method=RequestMethod.GET)
        public ModelAndView  showTraineeData()
           {
	             List<Training> li=trainingservice.showDetails();

	             return new ModelAndView("ScheduledSessions", "data", li);
            }
   /*****************************************************************************************************
             -Function Name   :   ShowSuccessData
             -Creation Date   :   01/11/2018
             -Description     :   ShowSuccessDetails
      
    ******************************************************************************************************/
         @RequestMapping(value="Success",method=RequestMethod.GET)
               public ModelAndView  showSucessData()
        {
	              List<Training> list11=trainingservice.showDetails();

	              return new ModelAndView("Success", "data11", list11);
         }

  }
