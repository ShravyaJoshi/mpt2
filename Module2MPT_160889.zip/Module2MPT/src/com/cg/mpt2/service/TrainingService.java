package com.cg.mpt2.service;

import java.util.List;

import com.cg.mpt2.dto.Training;

 public interface TrainingService 
   {
	
	 /**********Training details *************/
	 public List<Training> showDetails();
	 
	 
   }
