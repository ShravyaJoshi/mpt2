package com.cg.mpt2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mpt2.dao.TrainingDao;
import com.cg.mpt2.dto.Training;

@Service("trainingservice")
@Transactional
public class TrainingServiceImpl implements TrainingService
{
	
 @Autowired
 TrainingDao trainingdao;

 @Override
  public List<Training> showDetails()

   {
      return trainingdao.showDetails();
   }
 
 }
