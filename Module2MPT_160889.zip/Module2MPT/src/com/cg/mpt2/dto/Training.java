package com.cg.mpt2.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="ScheduledSessions")
public class Training {
//Primary Key
@Id
@Column(name="id")
@NotNull(message="not a valid id")
 Integer trainee_id;

@Column(name="name")
@NotEmpty(message="not a valid name")
		 String trainee_name;

@Column(name="duration")
@NotEmpty(message="not a valid duration")
		 Integer trainee_duration;

@Column(name="faculty")
		 String trainee_faculty;

@Column(name="mode1")
		 String trainee_mode;


 /***********************  Default Constructor ************************/

  public Training(){}
 /**********************  Parameterized Constructor ********************/    
  public Training(Integer trainee_id, String trainee_name,
		                   Integer trainee_duration, String trainee_faculty, String trainee_mode) {
	
	this.trainee_id       = trainee_id;
	this.trainee_name     = trainee_name;
	this.trainee_duration = trainee_duration;
	this.trainee_faculty  = trainee_faculty;
	this.trainee_mode     = trainee_mode;
}
/*************** These are required Getters And Setters ***************************/
  
  public Integer getTrainee_id() {
	   
	  return trainee_id;
    }
  public void setTrainee_id(Integer trainee_id) {
	   
	  this.trainee_id = trainee_id;
    }
  public String getTrainee_name() {
	  
	 return trainee_name;
     }
  public void setTrainee_name(String trainee_name) {
	  
	 this.trainee_name = trainee_name;
    }
  public Integer getTrainee_duration() {
	  
	 return trainee_duration;
    }
  public void setTrainee_duration(Integer trainee_duration) {
	  
	  this.trainee_duration = trainee_duration;
   }
  public String getTrainee_faculty() {
	
	return trainee_faculty;
   }
  public void setTrainee_faculty(String trainee_faculty) {
	
	this.trainee_faculty = trainee_faculty;
   }
  public String getTrainee_mode() {
	
	 return trainee_mode;
   }
  public void setTrainee_mode(String trainee_mode) {
	
	this.trainee_mode = trainee_mode;
  }

@Override
   public String toString() {
	return "Training [trainee_id=" + trainee_id + ", trainee_name="
			+ trainee_name + ", trainee_duration=" + trainee_duration
			+ ", trainee_faculty=" + trainee_faculty + ", trainee_mode="
			+ trainee_mode + "]";
      }
   }

	

